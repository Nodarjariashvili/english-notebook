# Handoff: Nono's English Notebook — Unit Dashboard (Calm Focus, option 1a)

## Overview
Unit-detail dashboard for an English-learning notebook app ("Lumen / Nono's English Notebook"). Shows daily streak, stars earned, unit progress, and a lesson list (Vocabulary, Grammar) with one expanded grammar detail card. This is the "Calm Focus" color direction: sage green + cream, chosen for a calm, low-cognitive-load study feel.

## About the Design Files
The bundled HTML files are **design references built as static HTML/CSS mockups** — not production code. The task is to recreate this screen in the target codebase's existing stack (React/Vue/native/etc.), using its established components, state management, and data layer. If no stack exists yet, pick the most suitable one and implement there.

Reference file: `Nono's Dashboard - Options.dc.html` — open it and look at the option labeled **1a "Calm Focus"** (the first card in the row). The other two cards (1b, 1c) are alternate color directions, not part of this handoff.

## Fidelity
**High-fidelity.** Colors, spacing, type sizes and animation timings below should be recreated pixel-close using the codebase's own component/styling system (don't copy raw inline styles verbatim).

## Screen: Unit Dashboard (Calm Focus)
**Purpose:** Nono opens a unit and sees today's motivation stats plus the lesson list to resume studying.

**Layout:** Single column card, ~720px max content width, 28–30px outer padding, background `oklch(97.5% 0.015 140)` (very light sage).
- Header row: flex, 14px gap — 46px circular avatar illustration slot, then a name/unit text block (Fraunces serif 19px `oklch(24% 0.03 145)` title; 12.5px `oklch(50% 0.02 140)` subtitle).
- Stats row: CSS grid, 3 equal columns, 14px gap. Each stat is a white card, 14px border-radius, 16px padding, centered text:
  1. **Streak** — small teardrop/flame icon shape (CSS `clip-path: polygon(50% 0%,100% 60%,80% 100%,20% 100%,0% 60%)`), fill `oklch(65% 0.13 145)`, count in 20px/800 weight, "day streak" label 11px muted.
  2. **Stars** — small diamond (22×22 square rotated 45°), fill `oklch(70% 0.1 200)`, count + "stars earned" label.
  3. **Progress** — 26px circular SVG progress ring, track `oklch(90% 0.02 145)`, fill `oklch(60% 0.12 145)`, percentage + "unit progress" label.
- Lesson list: vertical stack, 10px gap.
  - Collapsed row (Vocabulary): white card, left border accent 3px `oklch(65% 0.12 145)`, 24px icon swatch, title, trailing "x / y" count.
  - Expanded row (Grammar): same card style but taller, left border 3px `oklch(60% 0.13 145)`, icon swatch filled solid `oklch(60% 0.13 145)`, title + count in header row, plus a description line below (12px, `oklch(45% 0.02 60)`).

## Interactions & Behavior
- Rows/stat cards fade + slide up on mount, staggered ~50ms apart (see Animations).
- Lesson rows are collapsible/expandable (only one shown expanded in the mock — implement as an accordion: tap a collapsed row to expand it, collapsing others).
- Progress ring fill animates from 0 to its target percentage on mount.
- Streak icon has a continuous gentle pulse (breathing) to signal "alive/active" status.

## Animations (exact keyframes used in the mock)
- `fadeSlide`: `opacity 0→1`, `translateY(8px)→0`, 0.5s ease-out, staggered 0.05s per stat card.
- `pulseSoft` (streak icon): `scale(1)→scale(1.08)→scale(1)`, 2.6s ease-in-out, infinite.
- Progress ring: `stroke-dashoffset` animates from full (150) to target value, 1.2s ease-out, on mount only (not looping).

## Design Tokens
- Background (screen): `oklch(97.5% 0.015 140)`
- Card background: `#ffffff`
- Primary text: `oklch(24–28% 0.02–0.03 60/145)`
- Muted text: `oklch(50–55% 0.02 60/140)`
- Accent (sage green, streak/progress/grammar): `oklch(60–65% 0.12–0.13 145)`
- Secondary accent (stars, diamond): `oklch(70% 0.1 200)` (soft blue)
- Border radius: cards 14px, icon swatches 6px, avatar 50%
- Type: Fraunces (serif, headings, 500/600 weight), Nunito (body/UI, 400–800 weight)
- Spacing scale: 8 / 10 / 12 / 14 / 16 / 22 / 28–30px

## Assets
- Avatar circle is a placeholder (striped pattern) — replace with the user's real profile illustration/photo.
- No external icons used — streak/star icons are drawn with CSS shapes (clip-path teardrop, rotated square). Recreate as simple vector icons or SVGs in the target codebase; keep them equally simple (no photographic icon packs).

## Files
- `Nono's Dashboard - Options.dc.html` — contains 3 color-direction options; **use only option 1a** ("Calm Focus", first card).
